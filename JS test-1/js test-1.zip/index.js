// please uncomment 1 by 1 to check answer.



//1.return length of longest word in sentence

// var a="I tried so hard and got so far but in the End it doesntu even matter";
// var strSplit = a.split(' ');
// var longestWord = 0;
// for(var i = 0; i < strSplit.length; i++){
//   if(strSplit[i].length > longestWord){
//   longestWord = strSplit[i].length;
//    }
// }
// console.log(longestWord);




//2.make another array that returns sum of each arr elements in arr

// var a= [[2,67,44],[33,66,103],[11,34,90,22],[2,222,3,0.8]];
// const newarr=[];
// a.forEach((arr,i)=>{
//     let sum =0;
//     for(let k=0;k<arr.length;k++){
//         sum+=arr[k];        
//     }
//     newarr.push(sum)
    
// })

// console.log(newarr);







//3. palindrom
// var a="dad";
// var b="sad";
// let rev = a.split("").reverse().join("");
// if(rev== a){
//     console.log("true");
// }else{
//     console.log("false")
// }




//4. if a is any number alert not allowed
// var a = "Hi hello 34564.Hello Hi"
// if(a.match(/[0-9]/)){
//     alert("number not allowed")
// }



    
    
    

